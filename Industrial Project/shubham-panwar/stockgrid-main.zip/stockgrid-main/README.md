# 📦 StockGrid

> AI-powered inventory management system with smart insights, stock tracking, and automation.

---

## 🚀 Overview

StockGrid is a full-stack SaaS application designed to help businesses manage inventory efficiently, reduce stock issues, and make data-driven decisions using AI.

It replaces messy spreadsheets with a structured, scalable, and intelligent system.

---

## ✨ Features

### 📦 Inventory Management
- Product CRUD (Create, Read, Update, Delete)
- SKU-based product tracking
- Category management

### 🔄 Stock Tracking
- IN / OUT transactions
- Real-time stock calculation
- Complete audit trail

### 🚨 Alerts
- Low stock notifications
- Smart threshold handling

### 📊 Analytics
- Sales insights
- Top products
- Dead stock detection

### 🤖 AI Features
- Demand prediction
- Reorder suggestions
- AI-powered insights

### 📂 Import / Export
- CSV / Excel import
- Smart column mapping (AI-assisted)
- Data export for backup

### 🔐 Authentication
- JWT-based auth
- Role-based access (Admin / Manager / Staff)
- Secure password reset system

---

## 🛠️ Tech Stack

### Frontend
- React (Vite)
- Tailwind CSS

### Backend
- Node.js
- Express.js

### Database
- PostgreSQL (Supabase)

### Other
- Gmail SMTP (Email service)
- JWT (Authentication)

---

## 📁 Project Structure
